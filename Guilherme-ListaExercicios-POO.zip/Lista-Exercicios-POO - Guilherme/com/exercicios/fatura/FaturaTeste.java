package com.exercicios.fatura;

public class FaturaTeste {
    public static void main(String[] args) {
 
        Fatura fatura = new Fatura("001", "Teclado Mecânico", 3, 150.0);
        
   
        System.out.println("Código do Produto: " + fatura.getCodigoProduto());
        System.out.println("Descrição do Produto: " + fatura.getDescricaoProduto());
        System.out.println("Quantidade Comprada: " + fatura.getQuantidadeComprada());
        System.out.println("Preço por Item: " + fatura.getPrecoPorItem());
        System.out.printf("Total da Fatura: R$ %.2f%n", fatura.getTotalFatura());

        fatura.setQuantidadeComprada(-5);
        fatura.setPrecoPorItem(-50);

        System.out.println("\nApós atualizar com valores negativos:");
        System.out.println("Quantidade Comprada: " + fatura.getQuantidadeComprada());
        System.out.println("Preço por Item: " + fatura.getPrecoPorItem());
        System.out.printf("Total da Fatura: R$ %.2f%n", fatura.getTotalFatura());
    }
}