package com.exercicios.empregado;

public class EmpregadoTeste {
    public static void main(String[] args) {

        Empregado empregado1 = new Empregado("João", "Silva", 3000.0);
        Empregado empregado2 = new Empregado("Maria", "Oliveira", 4000.0);

        System.out.println("Salário anual de " + empregado1.getNome() + " " + empregado1.getSobrenome() + ": R$ " + String.format("%.2f", empregado1.getSalarioAnual()));
        System.out.println("Salário anual de " + empregado2.getNome() + " " + empregado2.getSobrenome() + ": R$ " + String.format("%.2f", empregado2.getSalarioAnual()));

        empregado1.aplicarAumento();
        empregado2.aplicarAumento();

        System.out.println("\nApós o aumento de 10%:");
        System.out.println("Novo salário anual de " + empregado1.getNome() + " " + empregado1.getSobrenome() + ": R$ " + String.format("%.2f", empregado1.getSalarioAnual()));
        System.out.println("Novo salário anual de " + empregado2.getNome() + " " + empregado2.getSobrenome() + ": R$ " + String.format("%.2f", empregado2.getSalarioAnual()));
    }
}
