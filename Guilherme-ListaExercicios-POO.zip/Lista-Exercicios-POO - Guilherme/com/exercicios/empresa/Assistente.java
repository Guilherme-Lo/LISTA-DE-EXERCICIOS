package com.exercicios.empresa;

public class Assistente extends Funcionario {
    public Assistente(String nome, double salarioBase) {
        super(nome, salarioBase);
    }
}
