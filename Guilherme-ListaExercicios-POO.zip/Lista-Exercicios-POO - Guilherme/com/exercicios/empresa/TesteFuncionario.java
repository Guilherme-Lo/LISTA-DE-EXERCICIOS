package com.exercicios.empresa;

public class TesteFuncionario {
    public static void main(String[] args) {
        Gerente gerente = new Gerente("Alice", 5000.00, 1000.00);
        Assistente assistente = new Assistente("Bob", 3000.00);

        System.out.println("Salário do Gerente: " + gerente.calcularSalario());
        System.out.println("Salário do Assistente: " + assistente.calcularSalario());
    }
}
