package com.exercicios.veiculos;

public class TesteVeiculo {
    public static void main(String[] args) {
        Veiculo veiculo = new Veiculo("Generic", "Modelo X", 2020);
        Carro carro = new Carro("Ford", "Mustang", 2022, 2);
        Moto moto = new Moto("Honda", "CBR", 2021, "Esportivo");

        System.out.println("Detalhes do Veículo:");
        veiculo.exibirDetalhes();

        System.out.println("\nDetalhes do Carro:");
        carro.exibirDetalhes();

        System.out.println("\nDetalhes da Moto:");
        moto.exibirDetalhes();
    }
}
