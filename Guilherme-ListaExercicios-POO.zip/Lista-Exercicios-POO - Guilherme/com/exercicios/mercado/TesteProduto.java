package com.exercicios.mercado;

public class TesteProduto {
    public static void main(String[] args) {
        Produto eletronico = new Eletronico("Smartphone", 1000.00, 12);
        Produto alimento = new Alimento("Maçã", 5.00, "2025-12-31");

        System.out.println("Preço com desconto do eletrônico: " + eletronico.calcularPrecoComDesconto());
        System.out.println("Preço com desconto do alimento: " + alimento.calcularPrecoComDesconto());
    }
}

