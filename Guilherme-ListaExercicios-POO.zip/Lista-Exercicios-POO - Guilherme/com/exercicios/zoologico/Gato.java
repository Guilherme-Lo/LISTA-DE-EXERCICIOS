package com.exercicios.zoologico;

public class Gato extends Animal {
    public Gato(String nome, int idade) {
        super(nome, idade);
    }

    @Override
    public String emitirSom() {
        return "O gato mia.";
    }
}
