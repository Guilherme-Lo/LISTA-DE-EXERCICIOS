package com.exercicios.zoologico;

public class TesteAnimal {
    public static void main(String[] args) {
        Animal cachorro = new Cachorro("Rex", 5);
        Animal gato = new Gato("Miau", 3);

        System.out.println(cachorro.emitirSom());
        System.out.println(gato.emitirSom());
    }
}
