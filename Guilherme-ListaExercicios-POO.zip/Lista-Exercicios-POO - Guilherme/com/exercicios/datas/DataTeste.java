package com.exercicios.datas;

public class DataTeste {
    public static void main(String[] args) {
        Data data = new Data(29, 9, 2024);

        data.displayData();
    
        // Valores inválidos
        data.setDia(32); 
        data.setMes(13); 
        data.setAno(-2024); 

         // Data após tentar definir valores inválidos
        data.displayData();
    }
}
